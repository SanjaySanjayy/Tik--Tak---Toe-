# Sorting_visualizer
effective visualization of sorting algorithms using html css and js.
